package jpabook1.jpashop1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jpashop1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
